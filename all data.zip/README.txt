COMPLETE DATABASE BACKUP
=========================
Exported: 12/12/2025, 12:49:53 AM
Total Records: 261 students, 15 faculty, 28 classes, 1010 attendance records

Files included:
1. students.json - All student records
2. faculty.json - All faculty records
3. classes.json - All class records
4. attendance.json - All attendance records (date-wise)
5. years.json - Academic years
6. settings.json - System settings
7. *.csv - CSV versions for easy viewing

To import: Use the "Complete Database Import" feature in the Bulk Import tab.